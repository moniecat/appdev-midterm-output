const users = require('../models/userModel');
const jwt = require('jsonwebtoken');
const Joi = require('joi');

// Register a new user
const register = (req, res) => {
  // Define validation schema
  const schema = Joi.object({
    username: Joi.string().min(3).required(),
    password: Joi.string().min(6).required(),
    email: Joi.string().email().required(),
  });

  // Validate request body
  const { error } = schema.validate(req.body);
  if (error) return res.status(400).send(error.details[0].message);

  // Create new user and push to users array
  const { username, password, email } = req.body;
  const newUser = { id: users.length + 1, username, password, email };
  users.push(newUser);
  res.status(201).send('User registered successfully');
};

// Login user and generate token
const login = (req, res) => {
  const { username, password } = req.body;
  const user = users.find(u => u.username === username && u.password === password);

  if (!user) return res.status(401).send('Invalid credentials');

  // Generate JWT token
  const token = jwt.sign({ id: user.id }, 'secretKey');
  res.json({ token });
};

// Get user profile
const getProfile = (req, res) => {
  const user = users.find(u => u.id === req.user.id);

  // Log found user for debugging
  console.log("User found:", user);

  if (!user) return res.status(404).send('User not found');

  // Remove id from user profile
  const { id, ...userProfile } = user;
  res.json(userProfile);
};

module.exports = { register, login, getProfile };
