// Create an in-memory array to store user data
const users = [];

module.exports = users;
