const express = require('express');
const { register, login, getProfile } = require('../controllers/userController');
const authMiddleware = require('../middleware/authMiddleware');

const router = express.Router();

// Define routes
router.post('/register', register); // User registration
router.post('/login', login);         // User login
router.get('/profile', authMiddleware, getProfile); // Get user profile

module.exports = router;
